package com.example.quiz1

open class Account(
    val accountNumber: String,
    var ownerName: String
) {
    private var balance: Double = 0.0

    fun getBalance(): Double {
        return balance
    }

    fun deposit(amount: Double) {
        if (amount > 0) {
            balance += amount
            println("დეპოზიტი წარმატებით განხორციელდა: $amount ₾. ახალი ბალანსი: $balance ₾")
        } else {
            println("დეპოზიტი ვერ შესრულდა. თანხა უნდა იყოს დადებითი.")
        }
    }

    open fun withdraw(amount: Double) {
        if (amount > 0 && balance >= amount) {
            balance -= amount
            println("გატანა წარმატებით განხორციელდა: $amount ₾. დარჩენილი ბალანსი: $balance ₾")
        } else {
            println("გატანა ვერ შესრულდა. შეამოწმეთ თანხა ან ბალანსი.")
        }
    }

    fun printInfo() {
        println("------ ანგარიშის ინფორმაცია ------")
        println("ანგარიშის ნომერი: $accountNumber")
        println("მფლობელი: $ownerName")
        println("ბალანსი: $balance ₾")
        println("---------------------------------")
    }

    protected fun setBalance(newBalance: Double) {
        balance = newBalance
    }
}
