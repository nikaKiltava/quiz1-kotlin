package com.example.quiz1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val acc1 = SavingsAccount("S101", "გიორგი გ.")
        val acc2 = VIPAccount("V202", "მარიამი ა.")

        // SavingsAccount ტესტი
        acc1.deposit(1000.0)
        acc1.withdraw(300.0)
        acc1.withdraw(600.0)

        // VIPAccount ტესტი
        acc2.deposit(1000.0)
        acc2.withdraw(50.0)
        acc2.printInfo()

        // პოლიმორფიზმი
        val accounts: List<Account> = listOf(acc1, acc2)
        for (account in accounts) {
            account.deposit(50.0)
            account.printInfo()
        }

        Log.d("TEST", "ტესტირება დასრულდა")
    }
}