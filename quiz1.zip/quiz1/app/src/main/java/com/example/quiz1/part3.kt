package com.example.quiz1

class VIPAccount(
    accountNumber: String,
    ownerName: String,
    private val transactionFee: Double = 2.0
) : Account(accountNumber, ownerName) {

    override fun withdraw(amount: Double) {
        val totalAmount = amount + transactionFee
        val currentBalance = getBalance()
        if (currentBalance >= totalAmount) {
            setBalance(currentBalance - totalAmount)
            println("VIP გატანა წარმატებით შესრულდა: $amount ₾ + საკომისიო $transactionFee ₾ = $totalAmount ₾")
        } else {
            println("გატანა ვერ შესრულდა. არასაკმარისი ბალანსი.")
        }
    }
}