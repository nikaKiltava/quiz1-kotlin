package com.example.quiz1

class SavingsAccount(
    accountNumber: String,
    ownerName: String
) : Account(accountNumber, ownerName) {

    override fun withdraw(amount: Double) {
        if (amount > 500) {
            println("შეცდომა: შემნახველი ანგარიშიდან ერთ ჯერზე შესაძლებელია მაქსიმუმ 500 ₾ გამოტანა.")
        } else {
            super.withdraw(amount)
        }
    }
}